<?php
/**
 * ZHIMA API: zhima.merchant.phone.ai.apply request
 *
 * @author auto create
 * @since 1.0, 2018-03-22 15:55:16
 */
class ZhimaMerchantPhoneAiApplyRequest
{
	/** 
	 * 
	 **/
	private $phonePicsInfo;
	
	/** 
	 * 
	 **/
	private $transactionId;

	private $apiParas = array();
	private $fileParas = array();
	private $apiVersion="1.0";
	private $scene;
	private $channel;
	private $platform;
	private $extParams;

	
	public function setPhonePicsInfo($phonePicsInfo)
	{
		$this->phonePicsInfo = $phonePicsInfo;
		$this->apiParas["phone_pics_info"] = $phonePicsInfo;
	}

	public function getPhonePicsInfo()
	{
		return $this->phonePicsInfo;
	}

	public function setTransactionId($transactionId)
	{
		$this->transactionId = $transactionId;
		$this->apiParas["transaction_id"] = $transactionId;
	}

	public function getTransactionId()
	{
		return $this->transactionId;
	}

	public function getApiMethodName()
	{
		return "zhima.merchant.phone.ai.apply";
	}

	public function setScene($scene)
	{
		$this->scene=$scene;
	}

	public function getScene()
	{
		return $this->scene;
	}
	
	public function setChannel($channel)
	{
		$this->channel=$channel;
	}

	public function getChannel()
	{
		return $this->channel;
	}
	
	public function setPlatform($platform)
	{
		$this->platform=$platform;
	}

	public function getPlatform()
	{
		return $this->platform;
	}

	public function setExtParams($extParams)
	{
		$this->extParams=$extParams;
	}

	public function getExtParams()
	{
		return $this->extParams;
	}	

	public function getApiParas()
	{
		return $this->apiParas;
	}
	
	public function getFileParas()
	{
		return $this->fileParas;
	}

	public function setApiVersion($apiVersion)
	{
		$this->apiVersion=$apiVersion;
	}

	public function getApiVersion()
	{
		return $this->apiVersion;
	}

}
